const Cursor = () => {
  return <div className="cursor" />;
};
export default Cursor;
